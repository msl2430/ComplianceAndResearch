var class_opto22_1_1_linearization_1_1_piecewise_linear =
[
    [ "PiecewiseLinear", "class_opto22_1_1_linearization_1_1_piecewise_linear.html#a09ed9758e1eb77c489be4ab042acaa73", null ],
    [ "Compute", "class_opto22_1_1_linearization_1_1_piecewise_linear.html#a6e2fe1e0204149f82a3cbd7616626be6", null ],
    [ "SetLookupElement", "class_opto22_1_1_linearization_1_1_piecewise_linear.html#a750f508f36f245e1e003f231da9bd65f", null ]
];