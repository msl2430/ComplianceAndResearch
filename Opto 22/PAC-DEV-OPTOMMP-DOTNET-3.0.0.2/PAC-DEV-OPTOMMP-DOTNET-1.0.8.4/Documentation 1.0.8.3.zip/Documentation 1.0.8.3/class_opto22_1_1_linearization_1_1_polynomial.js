var class_opto22_1_1_linearization_1_1_polynomial =
[
    [ "Polynomial", "class_opto22_1_1_linearization_1_1_polynomial.html#aefd442d19a791d71fc1549ae3d74b02d", null ],
    [ "Compute", "class_opto22_1_1_linearization_1_1_polynomial.html#a717d9a582fdab9a94be76a303401cc17", null ],
    [ "SetCoefficient", "class_opto22_1_1_linearization_1_1_polynomial.html#ad926770348286c07bbfbea56949ef778", null ]
];