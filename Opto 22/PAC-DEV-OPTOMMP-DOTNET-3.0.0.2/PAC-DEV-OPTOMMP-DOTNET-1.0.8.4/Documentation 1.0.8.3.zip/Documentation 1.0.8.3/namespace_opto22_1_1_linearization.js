var namespace_opto22_1_1_linearization =
[
    [ "Linear", "class_opto22_1_1_linearization_1_1_linear.html", "class_opto22_1_1_linearization_1_1_linear" ],
    [ "Polynomial", "class_opto22_1_1_linearization_1_1_polynomial.html", "class_opto22_1_1_linearization_1_1_polynomial" ],
    [ "PiecewiseLinear", "class_opto22_1_1_linearization_1_1_piecewise_linear.html", "class_opto22_1_1_linearization_1_1_piecewise_linear" ]
];