var class_opto22_1_1_linearization_1_1_linear =
[
    [ "Linear", "class_opto22_1_1_linearization_1_1_linear.html#a1661b9ebddf09df75589882d142827a2", null ],
    [ "Compute", "class_opto22_1_1_linearization_1_1_linear.html#a6b3af9111f7e03d18d3ffe13f272a7e3", null ],
    [ "SetEquation", "class_opto22_1_1_linearization_1_1_linear.html#a6cf6a094297adef13ebdce9633226320", null ]
];